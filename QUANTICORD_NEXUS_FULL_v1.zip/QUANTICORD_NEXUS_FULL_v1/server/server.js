
import express from 'express';
import cors from 'cors';
import http from 'http';
import { Server as IOServer } from 'socket.io';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => res.send('QUANTICORD NEXUS Server Activo'));

const server = http.createServer(app);
const io = new IOServer(server);

io.on('connection', socket => {
  console.log('Cliente conectado');
  socket.on('chat', data => io.emit('chat', data));
});

const PORT = process.env.PORT || 8787;
server.listen(PORT, () => console.log(`[QCN] Servidor activo en puerto ${PORT}`));
